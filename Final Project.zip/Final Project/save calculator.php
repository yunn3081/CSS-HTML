<p class="style1 style3">date：<?php echo $_POST['C_date']; ?></p>
<p class="style1 style3">details：<?php echo $_POST['C_details']; ?></p>
<p class="style1 style3">total sum：<?php echo $_POST['C_Sum']; ?></p>

<?php
header("Content-Type:text/html; charset=UTF-8");
$servername = "127.0.0.1";
$username = "liyun";
$password = "513191025";
$dbname = "calculator";

$C_date = $_POST['C_date'];
$C_details = $_POST['C_details'];
$C_sum = $_POST['C_Sum'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$queryStr = "INSERT INTO `calculator` (date,details,sum) VALUES ('$C_date','$C_details','$C_sum')";
//mysql_query($queryStr,$mysqlConnection) or die(mysql_error());

if ($conn->query($queryStr) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $queryStr . "<br>" . $conn->error;
}

$conn->close();
?>

