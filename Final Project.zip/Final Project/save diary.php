<p class="style1 style3">date：<?php echo $_POST['C_date']; ?></p>
<p class="style1 style3">diary：<?php echo $_POST['C_diary']; ?></p>
<p class="style1 style3">mood：<?php echo $_POST['C_mood']; ?></p>

<?php
header("Content-Type:text/html; charset=UTF-8");
$servername = "127.0.0.1";
$username = "liyun";
$password = "513191025";
$dbname = "final project";

$C_diary = $_POST['C_diary'];
$C_mood = $_POST['C_mood'];
$C_date = $_POST['C_date'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$queryStr = "INSERT INTO `final project` (date,mood,diary) VALUES ('$C_date','$C_mood','$C_diary')";
//mysql_query($queryStr,$mysqlConnection) or die(mysql_error());

if ($conn->query($queryStr) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $queryStr . "<br>" . $conn->error;
}

$conn->close();
?>

